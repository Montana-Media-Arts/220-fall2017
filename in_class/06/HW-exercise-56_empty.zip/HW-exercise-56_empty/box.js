
// A rectangular box

function Box(x, y ) {

}
